-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 31-Maio-2022 às 06:16
-- Versão do servidor: 10.4.24-MariaDB
-- versão do PHP: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `mysql`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `pedidosprodutos`
--

CREATE TABLE `pedidosprodutos` (
  `autoincrem` int(11) NOT NULL,
  `numero_pedido` int(11) NOT NULL,
  `codigo_produto` int(11) NOT NULL,
  `quantidade` double NOT NULL,
  `valor_unitario` double NOT NULL,
  `valor_total` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `pedidosprodutos`
--

INSERT INTO `pedidosprodutos` (`autoincrem`, `numero_pedido`, `codigo_produto`, `quantidade`, `valor_unitario`, `valor_total`) VALUES
(11, 16, 2, 9, 350, 3150),
(12, 16, 1, 3, 60, 180),
(13, 16, 1, 1, 60, 60),
(14, 19, 2, 1, 350, 350),
(15, 45, 2, 1, 350, 350),
(16, 45, 1, 1, 60, 60),
(35, 49, 2, 1, 350, 350),
(36, 50, 1, 1, 60, 60),
(37, 52, 2, 1, 350, 350),
(38, 52, 2, 1, 350, 350),
(39, 20, 2, 1, 350, 350),
(40, 20, 1, 1, 60, 60);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `pedidosprodutos`
--
ALTER TABLE `pedidosprodutos`
  ADD PRIMARY KEY (`autoincrem`),
  ADD KEY `fk_numero_pedido` (`numero_pedido`),
  ADD KEY `fk_codigo_produto` (`codigo_produto`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `pedidosprodutos`
--
ALTER TABLE `pedidosprodutos`
  MODIFY `autoincrem` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `pedidosprodutos`
--
ALTER TABLE `pedidosprodutos`
  ADD CONSTRAINT `pedidosprodutos_ibfk_1` FOREIGN KEY (`codigo_produto`) REFERENCES `produtos` (`codigo`),
  ADD CONSTRAINT `pedidosprodutos_ibfk_2` FOREIGN KEY (`numero_pedido`) REFERENCES `pedidosdadosgerais` (`numero_pedido`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
