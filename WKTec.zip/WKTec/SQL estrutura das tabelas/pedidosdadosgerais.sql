-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 31-Maio-2022 às 06:16
-- Versão do servidor: 10.4.24-MariaDB
-- versão do PHP: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `mysql`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `pedidosdadosgerais`
--

CREATE TABLE `pedidosdadosgerais` (
  `numero_pedido` int(11) NOT NULL,
  `codigo_cliente` int(11) NOT NULL,
  `data_emissao` date NOT NULL,
  `valor_total` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `pedidosdadosgerais`
--

INSERT INTO `pedidosdadosgerais` (`numero_pedido`, `codigo_cliente`, `data_emissao`, `valor_total`) VALUES
(4, 2, '2022-05-30', 0),
(5, 2, '2022-05-30', 0),
(6, 2, '2022-05-30', 0),
(7, 2, '2022-05-30', 0),
(8, 2, '2022-05-30', 0),
(9, 2, '2022-05-30', 0),
(10, 2, '2022-05-30', 0),
(11, 2, '2022-05-30', 0),
(12, 2, '2022-05-30', 0),
(13, 2, '2022-05-30', 0),
(14, 2, '2022-05-30', 0),
(15, 2, '2022-05-30', 0),
(16, 2, '2022-05-30', 0),
(17, 2, '2022-05-30', 0),
(18, 3, '2022-05-30', 0),
(19, 2, '2022-05-30', 0),
(20, 2, '2022-05-30', 0),
(21, 2, '2022-05-30', 0),
(22, 2, '2022-05-30', 0),
(23, 2, '2022-05-30', 0),
(24, 2, '2022-05-30', 0),
(25, 2, '2022-05-30', 0),
(26, 2, '2022-05-30', 0),
(27, 2, '2022-05-30', 0),
(28, 2, '2022-05-30', 0),
(29, 2, '2022-05-30', 0),
(30, 2, '2022-05-30', 0),
(31, 2, '2022-05-30', 0),
(32, 2, '2022-05-30', 0),
(33, 2, '2022-05-30', 0),
(34, 2, '2022-05-30', 0),
(35, 2, '2022-05-30', 0),
(36, 2, '2022-05-30', 0),
(37, 2, '2022-05-30', 0),
(38, 2, '2022-05-30', 0),
(39, 2, '2022-05-30', 0),
(40, 2, '2022-05-30', 0),
(41, 2, '2022-05-30', 0),
(42, 2, '2022-05-30', 0),
(43, 2, '2022-05-30', 0),
(44, 2, '2022-05-30', 0),
(45, 2, '2022-05-30', 0),
(46, 2, '2022-05-30', 0),
(47, 2, '2022-05-30', 0),
(48, 2, '2022-05-30', 0),
(49, 2, '2022-05-30', 0),
(50, 3, '2022-05-30', 0),
(51, 3, '2022-05-30', 0),
(52, 3, '2022-05-30', 0),
(53, 2, '2022-05-30', 0);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `pedidosdadosgerais`
--
ALTER TABLE `pedidosdadosgerais`
  ADD PRIMARY KEY (`numero_pedido`),
  ADD KEY `fk_codigo_cliente` (`codigo_cliente`),
  ADD KEY `data_emissao` (`numero_pedido`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `pedidosdadosgerais`
--
ALTER TABLE `pedidosdadosgerais`
  MODIFY `numero_pedido` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `pedidosdadosgerais`
--
ALTER TABLE `pedidosdadosgerais`
  ADD CONSTRAINT `pedidosdadosgerais_ibfk_1` FOREIGN KEY (`codigo_cliente`) REFERENCES `clientes` (`codigo`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
